namespace LibraryManagementSystem.Models
{
    public class Borrowing
    {
        public int BorrowingId { get; set; }
        public string BorrowingCode { get; set; } = string.Empty;
        public int MemberId { get; set; }
        public int BookId { get; set; }
        public DateTime BorrowDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public decimal Fine { get; set; }
        public string Status { get; set; } = "Dipinjam"; // Dipinjam, Dikembalikan, Terlambat

        // Untuk display
        public string? MemberName { get; set; }
        public string? BookTitle { get; set; }
        public string? BookCode { get; set; }

        // Function untuk calculate due date (7 hari dari tanggal pinjam)
        public void SetDueDate()
        {
            DueDate = BorrowDate.AddDays(7);
        }

        // Polymorphism - Virtual method untuk menghitung denda
        public virtual decimal HitungDenda()
        {
            if (ReturnDate == null || ReturnDate <= DueDate)
            {
                return 0;
            }

            // Hitung keterlambatan
            TimeSpan late = ReturnDate.Value - DueDate;
            int lateDays = (int)late.TotalDays;

            // Denda Rp 2.000 per hari
            decimal dendaPerHari = 2000;
            return lateDays * dendaPerHari;
        }

        // Function untuk cek apakah terlambat
        public bool IsLate()
        {
            if (ReturnDate != null)
            {
                return ReturnDate > DueDate;
            }
            return DateTime.Now > DueDate;
        }

        // Function untuk update status
        public void UpdateStatus()
        {
            if (ReturnDate != null)
            {
                Status = IsLate() ? "Terlambat" : "Dikembalikan";
            }
            else if (DateTime.Now > DueDate)
            {
                Status = "Terlambat";
            }
            else
            {
                Status = "Dipinjam";
            }
        }

        // Override ToString untuk display
        public override string ToString()
        {
            return $"{BorrowingCode} - {BookTitle} ({Status})";
        }
    }

    // Derived class untuk demonstrasi Polymorphism
    public class SpecialBorrowing : Borrowing
    {
        public bool IsPremiumMember { get; set; }

        // Override method HitungDenda - premium member dapat diskon 50%
        public override decimal HitungDenda()
        {
            decimal normalFine = base.HitungDenda();
            if (IsPremiumMember)
            {
                return normalFine * 0.5m; // Diskon 50%
            }
            return normalFine;
        }
    }
}
