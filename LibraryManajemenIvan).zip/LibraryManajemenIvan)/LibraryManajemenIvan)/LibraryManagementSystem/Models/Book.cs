namespace LibraryManagementSystem.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string BookCode { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string Publisher { get; set; } = string.Empty;
        public int PublishYear { get; set; }
        public string Category { get; set; } = string.Empty;
        public int Stock { get; set; }
        public int AvailableStock { get; set; }
        public DateTime CreatedDate { get; set; }

        // Function untuk validasi
        public bool IsAvailable()
        {
            return AvailableStock > 0;
        }

        // Function untuk mendapatkan info lengkap
        public string GetFullInfo()
        {
            return $"[{BookCode}] {Title} - {Author} ({PublishYear})\nStok: {AvailableStock}/{Stock}";
        }

        // Procedure untuk update stok
        public void UpdateStock(int borrowed)
        {
            AvailableStock = Stock - borrowed;
        }

        // Override ToString untuk display
        public override string ToString()
        {
            return $"{BookCode} - {Title}";
        }
    }
}
