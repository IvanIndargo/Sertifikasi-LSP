namespace LibraryManagementSystem.Models
{
    public class DashboardStats
    {
        public int TotalBooks { get; set; }
        public int TotalAvailableBooks { get; set; }
        public int TotalMembers { get; set; }
        public int TotalBorrowings { get; set; }
        public int ActiveBorrowings { get; set; }
        public int OverdueBorrowings { get; set; }
    }
}
