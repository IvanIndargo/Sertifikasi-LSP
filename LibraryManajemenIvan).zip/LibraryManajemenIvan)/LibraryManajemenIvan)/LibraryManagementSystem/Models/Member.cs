namespace LibraryManagementSystem.Models
{
    public class Member
    {
        public int MemberId { get; set; }
        public string MemberCode { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime JoinDate { get; set; }
        public bool IsActive { get; set; }

        // Function untuk validasi member aktif
        public bool CanBorrow()
        {
            return IsActive;
        }

        // Function untuk mendapatkan info lengkap
        public string GetFullInfo()
        {
            string status = IsActive ? "Aktif" : "Tidak Aktif";
            return $"[{MemberCode}] {FullName}\nTelp: {PhoneNumber}\nStatus: {status}";
        }

        // Override ToString untuk display
        public override string ToString()
        {
            return $"{MemberCode} - {FullName}";
        }
    }
}
