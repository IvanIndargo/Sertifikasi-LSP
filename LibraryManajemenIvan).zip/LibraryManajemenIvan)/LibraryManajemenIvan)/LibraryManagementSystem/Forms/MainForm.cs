using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            try
            {
                var db = new DatabaseHelper();
                if (!db.TestConnection())
                {
                    MessageBox.Show("Tidak dapat terhubung ke database.\n\nPastikan:\n1. MySQL Server sudah berjalan\n2. Database 'LibraryManagementDB' sudah dibuat\n3. Jalankan script SQL yang tersedia", 
                        "Peringatan Koneksi Database", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Tampilkan tampilan dashboard pertama kali
                ShowDashboard();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClearContent()
        {
            foreach (Control control in panelContent.Controls)
            {
                control.Dispose();
            }

            panelContent.Controls.Clear();
        }

        private void OpenChildForm(Form childForm)
        {
            ClearContent();

            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panelContent.Controls.Add(childForm);
            childForm.Show();
        }

        private void ShowDashboard()
        {
            ClearContent();

            var dashboardRepo = new DashboardRepository();
            DashboardStats stats;
            try
            {
                stats = dashboardRepo.GetStats();
            }
            catch
            {
                stats = new DashboardStats();
            }

            var dashboardPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(236, 240, 241),
                Padding = new Padding(30, 25, 30, 20)
            };

            var innerPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 320,
                BackColor = Color.Transparent
            };

            var lblWelcome = new Label
            {
                AutoSize = false,
                Dock = DockStyle.Top,
                Height = 50,
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.FromArgb(44, 62, 80),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(5, 0, 0, 0),
                Text = "Selamat datang di Dashboard Perpustakaan"
            };

            var lblInfo = new Label
            {
                AutoSize = false,
                Dock = DockStyle.Top,
                Height = 35,
                Font = new Font("Segoe UI", 10F),
                ForeColor = Color.FromArgb(52, 73, 94),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(7, 0, 0, 0),
                Text = "Ringkasan data buku, anggota, dan transaksi peminjaman."
            };

            var panelCards = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 3,
                RowCount = 2,
                Padding = new Padding(0, 18, 0, 0)
            };
            panelCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33f));
            panelCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33f));
            panelCards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34f));
            panelCards.RowStyles.Add(new RowStyle(SizeType.Absolute, 90f));
            panelCards.RowStyles.Add(new RowStyle(SizeType.Absolute, 90f));

            panelCards.Controls.Add(CreateStatCard("Total Buku", stats.TotalBooks.ToString(), Color.FromArgb(52, 152, 219)), 0, 0);
            panelCards.Controls.Add(CreateStatCard("Buku Tersedia", stats.TotalAvailableBooks.ToString(), Color.FromArgb(46, 204, 113)), 1, 0);
            panelCards.Controls.Add(CreateStatCard("Total Anggota", stats.TotalMembers.ToString(), Color.FromArgb(155, 89, 182)), 2, 0);
            panelCards.Controls.Add(CreateStatCard("Total Peminjaman", stats.TotalBorrowings.ToString(), Color.FromArgb(230, 126, 34)), 0, 1);
            panelCards.Controls.Add(CreateStatCard("Peminjaman Aktif", stats.ActiveBorrowings.ToString(), Color.FromArgb(241, 196, 15)), 1, 1);
            panelCards.Controls.Add(CreateStatCard("Peminjaman Terlambat", stats.OverdueBorrowings.ToString(), Color.FromArgb(231, 76, 60)), 2, 1);

            innerPanel.Controls.Add(panelCards);
            innerPanel.Controls.Add(lblInfo);
            innerPanel.Controls.Add(lblWelcome);

            // center innerPanel secara horizontal dengan lebar tetap
            innerPanel.Width = 720;
            innerPanel.Left = (dashboardPanel.ClientSize.Width - innerPanel.Width) / 2;
            innerPanel.Anchor = AnchorStyles.Top;

            dashboardPanel.Controls.Add(innerPanel);
            panelContent.Controls.Add(dashboardPanel);
        }

        private Control CreateStatCard(string title, string value, Color backColor)
        {
            var panel = new Panel
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(6),
                Padding = new Padding(0, 4, 0, 4),
                BackColor = backColor
            };

            var lblTitleCard = new Label
            {
                AutoSize = false,
                Dock = DockStyle.Top,
                Height = 26,
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(10, 0, 0, 0),
                Text = title
            };

            var lblValue = new Label
            {
                AutoSize = false,
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 16F, FontStyle.Bold),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Text = value
            };

            panel.Controls.Add(lblValue);
            panel.Controls.Add(lblTitleCard);

            return panel;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ShowDashboard();
        }

        private void btnBooks_Click(object sender, EventArgs e)
        {
            try
            {
                OpenChildForm(new BookForm());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error membuka halaman buku: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnMembers_Click(object sender, EventArgs e)
        {
            try
            {
                OpenChildForm(new MemberForm());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error membuka halaman anggota: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBorrowing_Click(object sender, EventArgs e)
        {
            try
            {
                OpenChildForm(new BorrowingForm());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error membuka halaman peminjaman: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            try
            {
                OpenChildForm(new ReturnForm());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error membuka halaman pengembalian: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            try
            {
                OpenChildForm(new HistoryForm());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error membuka halaman riwayat: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Apakah Anda yakin ingin keluar?", "Konfirmasi",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
