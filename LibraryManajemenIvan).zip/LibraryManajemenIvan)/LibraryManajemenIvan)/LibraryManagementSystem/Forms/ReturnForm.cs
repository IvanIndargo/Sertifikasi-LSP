using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Forms
{
    public partial class ReturnForm : Form
    {
        private readonly BorrowingRepository borrowingRepo;
        private readonly BookRepository bookRepo;
        private int selectedBorrowingId = 0;

        public ReturnForm()
        {
            InitializeComponent();
            borrowingRepo = new BorrowingRepository();
            bookRepo = new BookRepository();
        }

        private void ReturnForm_Load(object sender, EventArgs e)
        {
            try
            {
                LoadActiveBorrowings();
                dtpReturnDate.Value = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadActiveBorrowings()
        {
            try
            {
                var borrowings = borrowingRepo.GetActiveBorrowings();
                dgvBorrowings.DataSource = borrowings;

                if (dgvBorrowings.Columns.Count > 0)
                {
                    dgvBorrowings.Columns["BorrowingId"].Visible = false;
                    dgvBorrowings.Columns["MemberId"].Visible = false;
                    dgvBorrowings.Columns["BookId"].Visible = false;
                    dgvBorrowings.Columns["BorrowingCode"].HeaderText = "Kode";
                    dgvBorrowings.Columns["MemberName"].HeaderText = "Anggota";
                    dgvBorrowings.Columns["BookTitle"].HeaderText = "Buku";
                    dgvBorrowings.Columns["BookCode"].HeaderText = "Kode Buku";
                    dgvBorrowings.Columns["BorrowDate"].HeaderText = "Tgl Pinjam";
                    dgvBorrowings.Columns["BorrowDate"].DefaultCellStyle.Format = "dd/MM/yyyy";
                    dgvBorrowings.Columns["DueDate"].HeaderText = "Jatuh Tempo";
                    dgvBorrowings.Columns["DueDate"].DefaultCellStyle.Format = "dd/MM/yyyy";
                    dgvBorrowings.Columns["Status"].HeaderText = "Status";
                }

                lblTitle.Text = $"↩️ PENGEMBALIAN BUKU ({borrowings.Count} Peminjaman Aktif)";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvBorrowings_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dgvBorrowings.Rows[e.RowIndex];
                    selectedBorrowingId = Convert.ToInt32(row.Cells["BorrowingId"].Value);
                    
                    txtBorrowingCode.Text = row.Cells["BorrowingCode"].Value.ToString();
                    txtMemberName.Text = row.Cells["MemberName"].Value.ToString();
                    txtBookTitle.Text = row.Cells["BookTitle"].Value.ToString();
                    
                    DateTime dueDate = Convert.ToDateTime(row.Cells["DueDate"].Value);
                    DateTime returnDate = dtpReturnDate.Value;
                    
                    // Hitung denda menggunakan Polymorphism
                    var borrowing = new Borrowing
                    {
                        DueDate = dueDate,
                        ReturnDate = returnDate
                    };
                    
                    decimal fine = borrowing.HitungDenda();
                    txtFine.Text = fine.ToString("N0");
                    
                    if (fine > 0)
                    {
                        lblFineInfo.Text = $"⚠️ Terlambat {(returnDate - dueDate).Days} hari (Rp 2.000/hari)";
                        lblFineInfo.ForeColor = Color.Red;
                    }
                    else
                    {
                        lblFineInfo.Text = "✓ Tidak ada denda";
                        lblFineInfo.ForeColor = Color.Green;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dtpReturnDate_ValueChanged(object sender, EventArgs e)
        {
            // Re-calculate fine when return date changes
            if (selectedBorrowingId > 0 && dgvBorrowings.SelectedRows.Count > 0)
            {
                dgvBorrowings_CellClick(dgvBorrowings, 
                    new DataGridViewCellEventArgs(0, dgvBorrowings.SelectedRows[0].Index));
            }
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedBorrowingId == 0)
                {
                    MessageBox.Show("Pilih peminjaman yang akan dikembalikan!", "Validasi", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                decimal fine = decimal.Parse(txtFine.Text);
                var result = MessageBox.Show(
                    $"Proses pengembalian buku?\n\nDenda: Rp {fine:N0}", 
                    "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    if (borrowingRepo.ReturnBook(selectedBorrowingId, dtpReturnDate.Value, fine))
                    {
                        // Get book ID and update stock
                        var row = dgvBorrowings.SelectedRows[0];
                        int bookId = Convert.ToInt32(row.Cells["BookId"].Value);
                        var book = bookRepo.GetBookById(bookId);
                        if (book != null)
                        {
                            bookRepo.UpdateStock(bookId, book.AvailableStock + 1);
                        }

                        MessageBox.Show("Pengembalian berhasil diproses!", "Sukses", 
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        
                        ClearForm();
                        LoadActiveBorrowings();
                    }
                    else
                    {
                        MessageBox.Show("Gagal memproses pengembalian.", "Error", 
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClearForm()
        {
            selectedBorrowingId = 0;
            txtBorrowingCode.Clear();
            txtMemberName.Clear();
            txtBookTitle.Clear();
            txtFine.Text = "0";
            lblFineInfo.Text = "";
            dtpReturnDate.Value = DateTime.Now;
        }
    }
}
