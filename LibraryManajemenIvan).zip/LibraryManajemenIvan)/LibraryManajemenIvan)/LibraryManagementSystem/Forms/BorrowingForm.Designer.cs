namespace LibraryManagementSystem.Forms
{
    partial class BorrowingForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelTop;
        private Label lblTitle;
        private GroupBox groupBoxForm;
        private Label lblMember, lblBook, lblBorrowDate, lblDueDate;
        private ComboBox cmbMember, cmbBook;
        private DateTimePicker dtpBorrowDate, dtpDueDate;
        private Button btnBorrow, btnClear, btnClose;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelTop = new Panel();
            this.lblTitle = new Label();
            this.groupBoxForm = new GroupBox();
            this.lblMember = new Label();
            this.cmbMember = new ComboBox();
            this.lblBook = new Label();
            this.cmbBook = new ComboBox();
            this.lblBorrowDate = new Label();
            this.dtpBorrowDate = new DateTimePicker();
            this.lblDueDate = new Label();
            this.dtpDueDate = new DateTimePicker();
            this.btnBorrow = new Button();
            this.btnClear = new Button();
            this.btnClose = new Button();

            // Panel Top
            this.panelTop.BackColor = Color.FromArgb(155, 89, 182);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock = DockStyle.Top;
            this.panelTop.Size = new Size(700, 60);

            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.White;
            this.lblTitle.Location = new Point(230, 15);
            this.lblTitle.Text = "📖 PEMINJAMAN BUKU";

            // GroupBox Form
            this.groupBoxForm.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.groupBoxForm.Location = new Point(50, 90);
            this.groupBoxForm.Size = new Size(600, 280);
            this.groupBoxForm.Text = "Form Peminjaman";

            this.lblMember.Font = new Font("Segoe UI", 9F);
            this.lblMember.Location = new Point(30, 30);
            this.lblMember.Text = "Pilih Anggota";
            this.cmbMember.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbMember.Location = new Point(30, 50);
            this.cmbMember.Size = new Size(540, 23);

            this.lblBook.Font = new Font("Segoe UI", 9F);
            this.lblBook.Location = new Point(30, 85);
            this.lblBook.Text = "Pilih Buku";
            this.cmbBook.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cmbBook.Location = new Point(30, 105);
            this.cmbBook.Size = new Size(540, 23);

            this.lblBorrowDate.Font = new Font("Segoe UI", 9F);
            this.lblBorrowDate.Location = new Point(30, 140);
            this.lblBorrowDate.Text = "Tanggal Pinjam";
            this.dtpBorrowDate.Location = new Point(30, 160);
            this.dtpBorrowDate.Size = new Size(250, 23);
            this.dtpBorrowDate.ValueChanged += new EventHandler(this.dtpBorrowDate_ValueChanged);

            this.lblDueDate.Font = new Font("Segoe UI", 9F);
            this.lblDueDate.Location = new Point(320, 140);
            this.lblDueDate.Text = "Tanggal Jatuh Tempo";
            this.dtpDueDate.Location = new Point(320, 160);
            this.dtpDueDate.Size = new Size(250, 23);
            this.dtpDueDate.Enabled = false;

            this.btnBorrow.BackColor = Color.FromArgb(155, 89, 182);
            this.btnBorrow.FlatStyle = FlatStyle.Flat;
            this.btnBorrow.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            this.btnBorrow.ForeColor = Color.White;
            this.btnBorrow.Location = new Point(30, 210);
            this.btnBorrow.Size = new Size(350, 45);
            this.btnBorrow.Text = "💾 Simpan Peminjaman";
            this.btnBorrow.Click += new EventHandler(this.btnBorrow_Click);

            this.btnClear.BackColor = Color.FromArgb(149, 165, 166);
            this.btnClear.FlatStyle = FlatStyle.Flat;
            this.btnClear.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            this.btnClear.ForeColor = Color.White;
            this.btnClear.Location = new Point(390, 210);
            this.btnClear.Size = new Size(180, 45);
            this.btnClear.Text = "🔄 Clear";
            this.btnClear.Click += new EventHandler(this.btnClear_Click);

            this.btnClose.BackColor = Color.FromArgb(231, 76, 60);
            this.btnClose.FlatStyle = FlatStyle.Flat;
            this.btnClose.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnClose.ForeColor = Color.White;
            this.btnClose.Location = new Point(275, 390);
            this.btnClose.Size = new Size(150, 40);
            this.btnClose.Text = "❌ Tutup";
            this.btnClose.Click += new EventHandler(this.btnClose_Click);

            this.groupBoxForm.Controls.AddRange(new Control[] {
                this.lblMember, this.cmbMember,
                this.lblBook, this.cmbBook,
                this.lblBorrowDate, this.dtpBorrowDate,
                this.lblDueDate, this.dtpDueDate,
                this.btnBorrow, this.btnClear
            });

            // Form
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.FromArgb(236, 240, 241);
            this.ClientSize = new Size(700, 450);
            this.Controls.AddRange(new Control[] {
                this.panelTop, this.groupBoxForm, this.btnClose
            });
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Peminjaman Buku - Library Management System";
            this.Load += new EventHandler(this.BorrowingForm_Load);
        }
    }
}
