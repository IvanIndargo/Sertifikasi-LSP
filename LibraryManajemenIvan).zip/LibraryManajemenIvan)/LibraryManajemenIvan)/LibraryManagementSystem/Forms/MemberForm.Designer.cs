namespace LibraryManagementSystem.Forms
{
    partial class MemberForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelTop;
        private Label lblTitle;
        private GroupBox groupBoxForm;
        private TextBox txtMemberCode, txtFullName, txtAddress, txtPhoneNumber, txtEmail;
        private Label lblMemberCode, lblFullName, lblAddress, lblPhoneNumber, lblEmail;
        private CheckBox chkActive;
        private GroupBox groupBoxButtons;
        private Button btnAdd, btnUpdate, btnDelete, btnClear;
        private GroupBox groupBoxSearch;
        private TextBox txtSearch;
        private Button btnSearch, btnRefresh;
        private DataGridView dgvMembers;
        private Button btnClose;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelTop = new Panel();
            this.lblTitle = new Label();
            this.groupBoxForm = new GroupBox();
            this.txtMemberCode = new TextBox();
            this.lblMemberCode = new Label();
            this.txtFullName = new TextBox();
            this.lblFullName = new Label();
            this.txtAddress = new TextBox();
            this.lblAddress = new Label();
            this.txtPhoneNumber = new TextBox();
            this.lblPhoneNumber = new Label();
            this.txtEmail = new TextBox();
            this.lblEmail = new Label();
            this.chkActive = new CheckBox();
            this.groupBoxButtons = new GroupBox();
            this.btnAdd = new Button();
            this.btnUpdate = new Button();
            this.btnDelete = new Button();
            this.btnClear = new Button();
            this.groupBoxSearch = new GroupBox();
            this.txtSearch = new TextBox();
            this.btnSearch = new Button();
            this.btnRefresh = new Button();
            this.dgvMembers = new DataGridView();
            this.btnClose = new Button();

            // Panel Top
            this.panelTop.BackColor = Color.FromArgb(46, 204, 113);
            this.panelTop.Controls.Add(this.lblTitle);
            this.panelTop.Dock = DockStyle.Top;
            this.panelTop.Size = new Size(1200, 60);

            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            this.lblTitle.ForeColor = Color.White;
            this.lblTitle.Location = new Point(450, 15);
            this.lblTitle.Text = "👥 MANAJEMEN ANGGOTA";

            // GroupBox Form
            this.groupBoxForm.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.groupBoxForm.Location = new Point(20, 80);
            this.groupBoxForm.Size = new Size(350, 340);
            this.groupBoxForm.Text = "Form Data Anggota";
            this.groupBoxForm.Controls.AddRange(new Control[] {
                this.lblMemberCode, this.txtMemberCode,
                this.lblFullName, this.txtFullName,
                this.lblAddress, this.txtAddress,
                this.lblPhoneNumber, this.txtPhoneNumber,
                this.lblEmail, this.txtEmail,
                this.chkActive
            });

            this.lblMemberCode.Location = new Point(20, 27);
            this.lblMemberCode.Text = "Kode Anggota";
            this.txtMemberCode.Location = new Point(20, 45);
            this.txtMemberCode.Size = new Size(310, 23);

            this.lblFullName.Location = new Point(20, 75);
            this.lblFullName.Text = "Nama Lengkap";
            this.txtFullName.Location = new Point(20, 93);
            this.txtFullName.Size = new Size(310, 23);

            this.lblAddress.Location = new Point(20, 123);
            this.lblAddress.Text = "Alamat";
            this.txtAddress.Location = new Point(20, 141);
            this.txtAddress.Size = new Size(310, 60);
            this.txtAddress.Multiline = true;

            this.lblPhoneNumber.Location = new Point(20, 207);
            this.lblPhoneNumber.Text = "No. Telepon";
            this.txtPhoneNumber.Location = new Point(20, 225);
            this.txtPhoneNumber.Size = new Size(310, 23);

            this.lblEmail.Location = new Point(20, 255);
            this.lblEmail.Text = "Email";
            this.txtEmail.Location = new Point(20, 273);
            this.txtEmail.Size = new Size(310, 23);

            this.chkActive.Location = new Point(20, 305);
            this.chkActive.Text = "Anggota Aktif";
            this.chkActive.Checked = true;

            // GroupBox Buttons
            this.groupBoxButtons.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.groupBoxButtons.Location = new Point(20, 430);
            this.groupBoxButtons.Size = new Size(350, 100);
            this.groupBoxButtons.Text = "Aksi";
            this.groupBoxButtons.Controls.AddRange(new Control[] {
                this.btnAdd, this.btnUpdate, this.btnDelete, this.btnClear
            });

            this.btnAdd.BackColor = Color.FromArgb(46, 204, 113);
            this.btnAdd.FlatStyle = FlatStyle.Flat;
            this.btnAdd.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnAdd.ForeColor = Color.White;
            this.btnAdd.Location = new Point(20, 30);
            this.btnAdd.Size = new Size(150, 35);
            this.btnAdd.Text = "➕ Tambah";
            this.btnAdd.Click += new EventHandler(this.btnAdd_Click);

            this.btnUpdate.BackColor = Color.FromArgb(52, 152, 219);
            this.btnUpdate.FlatStyle = FlatStyle.Flat;
            this.btnUpdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnUpdate.ForeColor = Color.White;
            this.btnUpdate.Location = new Point(180, 30);
            this.btnUpdate.Size = new Size(150, 35);
            this.btnUpdate.Text = "✏️ Update";
            this.btnUpdate.Click += new EventHandler(this.btnUpdate_Click);

            this.btnDelete.BackColor = Color.FromArgb(231, 76, 60);
            this.btnDelete.FlatStyle = FlatStyle.Flat;
            this.btnDelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnDelete.ForeColor = Color.White;
            this.btnDelete.Location = new Point(20, 70);
            this.btnDelete.Size = new Size(150, 35);
            this.btnDelete.Text = "🗑️ Hapus";
            this.btnDelete.Click += new EventHandler(this.btnDelete_Click);

            this.btnClear.BackColor = Color.FromArgb(149, 165, 166);
            this.btnClear.FlatStyle = FlatStyle.Flat;
            this.btnClear.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnClear.ForeColor = Color.White;
            this.btnClear.Location = new Point(180, 70);
            this.btnClear.Size = new Size(150, 35);
            this.btnClear.Text = "🔄 Clear";
            this.btnClear.Click += new EventHandler(this.btnClear_Click);

            // GroupBox Search
            this.groupBoxSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.groupBoxSearch.Location = new Point(390, 80);
            this.groupBoxSearch.Size = new Size(790, 70);
            this.groupBoxSearch.Text = "Pencarian";
            this.groupBoxSearch.Controls.AddRange(new Control[] {
                this.txtSearch, this.btnSearch, this.btnRefresh
            });

            this.txtSearch.Location = new Point(20, 30);
            this.txtSearch.Size = new Size(550, 23);
            this.txtSearch.PlaceholderText = "Cari berdasarkan kode, nama, atau telepon...";

            this.btnSearch.BackColor = Color.FromArgb(52, 152, 219);
            this.btnSearch.FlatStyle = FlatStyle.Flat;
            this.btnSearch.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnSearch.ForeColor = Color.White;
            this.btnSearch.Location = new Point(580, 28);
            this.btnSearch.Size = new Size(90, 27);
            this.btnSearch.Text = "🔍 Cari";
            this.btnSearch.Click += new EventHandler(this.btnSearch_Click);

            this.btnRefresh.BackColor = Color.FromArgb(46, 204, 113);
            this.btnRefresh.FlatStyle = FlatStyle.Flat;
            this.btnRefresh.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.btnRefresh.ForeColor = Color.White;
            this.btnRefresh.Location = new Point(680, 28);
            this.btnRefresh.Size = new Size(90, 27);
            this.btnRefresh.Text = "🔄 Refresh";
            this.btnRefresh.Click += new EventHandler(this.btnRefresh_Click);

            // DataGridView
            this.dgvMembers.AllowUserToAddRows = false;
            this.dgvMembers.AllowUserToDeleteRows = false;
            this.dgvMembers.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvMembers.BackgroundColor = Color.White;
            this.dgvMembers.Location = new Point(390, 160);
            this.dgvMembers.MultiSelect = false;
            this.dgvMembers.ReadOnly = true;
            this.dgvMembers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dgvMembers.Size = new Size(790, 370);
            this.dgvMembers.CellClick += new DataGridViewCellEventHandler(this.dgvMembers_CellClick);

            // Button Close
            this.btnClose.BackColor = Color.FromArgb(231, 76, 60);
            this.btnClose.FlatStyle = FlatStyle.Flat;
            this.btnClose.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            this.btnClose.ForeColor = Color.White;
            this.btnClose.Location = new Point(1040, 540);
            this.btnClose.Size = new Size(140, 40);
            this.btnClose.Text = "❌ Tutup";
            this.btnClose.Click += new EventHandler(this.btnClose_Click);

            // Form
            this.AutoScaleDimensions = new SizeF(7F, 15F);
            this.AutoScaleMode = AutoScaleMode.Font;
            this.BackColor = Color.FromArgb(236, 240, 241);
            this.ClientSize = new Size(1200, 590);
            this.Controls.AddRange(new Control[] {
                this.panelTop, this.groupBoxForm, this.groupBoxButtons,
                this.groupBoxSearch, this.dgvMembers, this.btnClose
            });
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Manajemen Anggota - Library Management System";
            this.Load += new EventHandler(this.MemberForm_Load);
        }
    }
}
