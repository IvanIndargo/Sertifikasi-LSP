using LibraryManagementSystem.Data;
using LibraryManagementSystem.Utils;

namespace LibraryManagementSystem.Forms
{
    public partial class HistoryForm : Form
    {
        private readonly BorrowingRepository borrowingRepo;
        private readonly BookRepository bookRepo;
        private readonly MemberRepository memberRepo;

        public HistoryForm()
        {
            InitializeComponent();
            borrowingRepo = new BorrowingRepository();
            bookRepo = new BookRepository();
            memberRepo = new MemberRepository();
        }

        private void HistoryForm_Load(object sender, EventArgs e)
        {
            try
            {
                cmbStatus.SelectedIndex = 0;
                LoadHistory();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadHistory()
        {
            try
            {
                var borrowings = borrowingRepo.GetAllBorrowings();

                // Filter by status if not "Semua"
                if (cmbStatus.SelectedIndex > 0)
                {
                    string status = cmbStatus.Text;
                    borrowings = borrowings.Where(b => b.Status == status).ToList();
                }

                dgvHistory.DataSource = borrowings;

                if (dgvHistory.Columns.Count > 0)
                {
                    dgvHistory.Columns["BorrowingId"].Visible = false;
                    dgvHistory.Columns["MemberId"].Visible = false;
                    dgvHistory.Columns["BookId"].Visible = false;
                    dgvHistory.Columns["BorrowingCode"].HeaderText = "Kode";
                    dgvHistory.Columns["MemberName"].HeaderText = "Anggota";
                    dgvHistory.Columns["BookTitle"].HeaderText = "Buku";
                    dgvHistory.Columns["BookCode"].HeaderText = "Kode Buku";
                    dgvHistory.Columns["BorrowDate"].HeaderText = "Tgl Pinjam";
                    dgvHistory.Columns["BorrowDate"].DefaultCellStyle.Format = "dd/MM/yyyy";
                    dgvHistory.Columns["DueDate"].HeaderText = "Jatuh Tempo";
                    dgvHistory.Columns["DueDate"].DefaultCellStyle.Format = "dd/MM/yyyy";
                    dgvHistory.Columns["ReturnDate"].HeaderText = "Tgl Kembali";
                    dgvHistory.Columns["ReturnDate"].DefaultCellStyle.Format = "dd/MM/yyyy";
                    dgvHistory.Columns["Fine"].HeaderText = "Denda";
                    dgvHistory.Columns["Fine"].DefaultCellStyle.Format = "N0";
                    dgvHistory.Columns["Status"].HeaderText = "Status";
                }

                // Calculate statistics
                int totalBorrowings = borrowings.Count;
                int activeBorrowings = borrowings.Count(b => b.Status == "Dipinjam");
                int lateBorrowings = borrowings.Count(b => b.Status == "Terlambat");
                decimal totalFines = borrowings.Sum(b => b.Fine);

                //lblStats.Text = $"Total: {totalBorrowings} | Aktif: {activeBorrowings} | Terlambat: {lateBorrowings} | Total Denda: Rp {totalFines:N0}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading history: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cmbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadHistory();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string keyword = txtSearch.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    LoadHistory();
                    return;
                }

                var borrowings = borrowingRepo.SearchBorrowings(keyword);
                dgvHistory.DataSource = borrowings;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            cmbStatus.SelectedIndex = 0;
            LoadHistory();
        }

        private void btnExportTxt_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "Text Files (*.txt)|*.txt",
                    FileName = $"Riwayat_Peminjaman_{DateTime.Now:yyyyMMdd}.txt"
                };

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    var data = new List<string[]>();
                    foreach (DataGridViewRow row in dgvHistory.Rows)
                    {
                        var rowData = new string[]
                        {
                            row.Cells["BorrowingCode"].Value?.ToString() ?? "",
                            row.Cells["MemberName"].Value?.ToString() ?? "",
                            row.Cells["BookTitle"].Value?.ToString() ?? "",
                            row.Cells["BorrowDate"].Value != null ?
                                Convert.ToDateTime(row.Cells["BorrowDate"].Value).ToString("dd/MM/yyyy") : "",
                            row.Cells["DueDate"].Value != null ?
                                Convert.ToDateTime(row.Cells["DueDate"].Value).ToString("dd/MM/yyyy") : "",
                            row.Cells["ReturnDate"].Value != null && row.Cells["ReturnDate"].Value != DBNull.Value ?
                                Convert.ToDateTime(row.Cells["ReturnDate"].Value).ToString("dd/MM/yyyy") : "-",
                            row.Cells["Fine"].Value?.ToString() ?? "0",
                            row.Cells["Status"].Value?.ToString() ?? ""
                        };
                        data.Add(rowData);
                    }

                    string[] headers = { "Kode", "Anggota", "Buku", "Tgl Pinjam", "Jatuh Tempo", "Tgl Kembali", "Denda", "Status" };

                    if (FileExporter.ExportToTxt(sfd.FileName, data, headers))
                    {
                        MessageBox.Show("Data berhasil di-export ke TXT!", "Sukses",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Gagal export data.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExportCsv_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog sfd = new SaveFileDialog
                {
                    Filter = "CSV Files (*.csv)|*.csv",
                    FileName = $"Riwayat_Peminjaman_{DateTime.Now:yyyyMMdd}.csv"
                };

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    var data = new List<string[]>();
                    foreach (DataGridViewRow row in dgvHistory.Rows)
                    {
                        var rowData = new string[]
                        {
                            row.Cells["BorrowingCode"].Value?.ToString() ?? "",
                            row.Cells["MemberName"].Value?.ToString() ?? "",
                            row.Cells["BookTitle"].Value?.ToString() ?? "",
                            row.Cells["BorrowDate"].Value != null ?
                                Convert.ToDateTime(row.Cells["BorrowDate"].Value).ToString("dd/MM/yyyy") : "",
                            row.Cells["DueDate"].Value != null ?
                                Convert.ToDateTime(row.Cells["DueDate"].Value).ToString("dd/MM/yyyy") : "",
                            row.Cells["ReturnDate"].Value != null && row.Cells["ReturnDate"].Value != DBNull.Value ?
                                Convert.ToDateTime(row.Cells["ReturnDate"].Value).ToString("dd/MM/yyyy") : "-",
                            row.Cells["Fine"].Value?.ToString() ?? "0",
                            row.Cells["Status"].Value?.ToString() ?? ""
                        };
                        data.Add(rowData);
                    }

                    string[] headers = { "Kode", "Anggota", "Buku", "Tanggal Pinjam", "Jatuh Tempo", "Tanggal Kembali", "Denda", "Status" };

                    if (FileExporter.ExportToCsv(sfd.FileName, data, headers))
                    {
                        MessageBox.Show("Data berhasil di-export ke CSV!", "Sukses",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Gagal export data.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void groupBoxExport_Enter(object sender, EventArgs e)
        {

        }
    }
}
