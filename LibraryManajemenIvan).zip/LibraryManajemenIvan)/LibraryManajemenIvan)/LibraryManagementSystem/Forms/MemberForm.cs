using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Forms
{
    public partial class MemberForm : Form
    {
        private readonly MemberRepository memberRepo;
        private int selectedMemberId = 0;

        public MemberForm()
        {
            InitializeComponent();
            memberRepo = new MemberRepository();
        }

        private void MemberForm_Load(object sender, EventArgs e)
        {
            try
            {
                LoadMembers();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading form: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadMembers()
        {
            try
            {
                var members = memberRepo.GetAllMembers();
                dgvMembers.DataSource = members;

                if (dgvMembers.Columns.Count > 0)
                {
                    dgvMembers.Columns["MemberId"].HeaderText = "ID";
                    dgvMembers.Columns["MemberId"].Width = 50;
                    dgvMembers.Columns["MemberCode"].HeaderText = "Kode Anggota";
                    dgvMembers.Columns["FullName"].HeaderText = "Nama Lengkap";
                    dgvMembers.Columns["Address"].HeaderText = "Alamat";
                    dgvMembers.Columns["PhoneNumber"].HeaderText = "No. Telepon";
                    dgvMembers.Columns["Email"].HeaderText = "Email";
                    dgvMembers.Columns["JoinDate"].HeaderText = "Tanggal Bergabung";
                    dgvMembers.Columns["JoinDate"].DefaultCellStyle.Format = "dd/MM/yyyy";
                    dgvMembers.Columns["IsActive"].HeaderText = "Aktif";
                }

                lblTitle.Text = $"👥 MANAJEMEN ANGGOTA ({members.Count} Anggota)";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading members: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateInput()) return;

                var member = new Member
                {
                    MemberCode = txtMemberCode.Text.Trim(),
                    FullName = txtFullName.Text.Trim(),
                    Address = txtAddress.Text.Trim(),
                    PhoneNumber = txtPhoneNumber.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    IsActive = chkActive.Checked
                };

                if (memberRepo.AddMember(member))
                {
                    MessageBox.Show("Anggota berhasil ditambahkan!", "Sukses", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadMembers();
                    ClearForm();
                }
                else
                {
                    MessageBox.Show("Gagal menambahkan anggota.", "Error", 
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedMemberId == 0)
                {
                    MessageBox.Show("Pilih anggota yang akan diupdate!", "Peringatan", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!ValidateInput()) return;

                var member = new Member
                {
                    MemberId = selectedMemberId,
                    MemberCode = txtMemberCode.Text.Trim(),
                    FullName = txtFullName.Text.Trim(),
                    Address = txtAddress.Text.Trim(),
                    PhoneNumber = txtPhoneNumber.Text.Trim(),
                    Email = txtEmail.Text.Trim(),
                    IsActive = chkActive.Checked
                };

                if (memberRepo.UpdateMember(member))
                {
                    MessageBox.Show("Anggota berhasil diupdate!", "Sukses", 
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadMembers();
                    ClearForm();
                }
                else
                {
                    MessageBox.Show("Gagal mengupdate anggota.", "Error", 
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (selectedMemberId == 0)
                {
                    MessageBox.Show("Pilih anggota yang akan dihapus!", "Peringatan", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var result = MessageBox.Show("Apakah Anda yakin ingin menghapus anggota ini?", 
                    "Konfirmasi Hapus", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    if (memberRepo.DeleteMember(selectedMemberId))
                    {
                        MessageBox.Show("Anggota berhasil dihapus!", "Sukses", 
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadMembers();
                        ClearForm();
                    }
                    else
                    {
                        MessageBox.Show("Gagal menghapus anggota.", "Error", 
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                string keyword = txtSearch.Text.Trim();
                if (string.IsNullOrEmpty(keyword))
                {
                    LoadMembers();
                    return;
                }

                var members = memberRepo.SearchMembers(keyword);
                dgvMembers.DataSource = members;
                lblTitle.Text = $"👥 MANAJEMEN ANGGOTA ({members.Count} Hasil Pencarian)";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            LoadMembers();
        }

        private void dgvMembers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dgvMembers.Rows[e.RowIndex];
                    selectedMemberId = Convert.ToInt32(row.Cells["MemberId"].Value);
                    txtMemberCode.Text = row.Cells["MemberCode"].Value.ToString();
                    txtFullName.Text = row.Cells["FullName"].Value.ToString();
                    txtAddress.Text = row.Cells["Address"].Value.ToString();
                    txtPhoneNumber.Text = row.Cells["PhoneNumber"].Value.ToString();
                    txtEmail.Text = row.Cells["Email"].Value.ToString();
                    chkActive.Checked = Convert.ToBoolean(row.Cells["IsActive"].Value);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(txtMemberCode.Text))
            {
                MessageBox.Show("Kode anggota tidak boleh kosong!", "Validasi", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMemberCode.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtFullName.Text))
            {
                MessageBox.Show("Nama lengkap tidak boleh kosong!", "Validasi", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtFullName.Focus();
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtPhoneNumber.Text))
            {
                MessageBox.Show("No. telepon tidak boleh kosong!", "Validasi", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPhoneNumber.Focus();
                return false;
            }

            return true;
        }

        private void ClearForm()
        {
            selectedMemberId = 0;
            txtMemberCode.Clear();
            txtFullName.Clear();
            txtAddress.Clear();
            txtPhoneNumber.Clear();
            txtEmail.Clear();
            chkActive.Checked = true;
            txtMemberCode.Focus();
        }
    }
}
