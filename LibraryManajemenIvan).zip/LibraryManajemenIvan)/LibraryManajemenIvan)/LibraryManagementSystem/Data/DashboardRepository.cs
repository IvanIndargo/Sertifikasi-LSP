using MySql.Data.MySqlClient;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data
{
    public class DashboardRepository
    {
        private readonly DatabaseHelper db;

        public DashboardRepository()
        {
            db = new DatabaseHelper();
        }

        public DashboardStats GetStats()
        {
            var stats = new DashboardStats();

            try
            {
                // Total buku
                stats.TotalBooks = ExecuteCount("SELECT COUNT(*) FROM Books");

                // Total stok buku tersedia (jumlah AvailableStock)
                stats.TotalAvailableBooks = ExecuteCount("SELECT IFNULL(SUM(AvailableStock), 0) FROM Books");

                // Total anggota
                stats.TotalMembers = ExecuteCount("SELECT COUNT(*) FROM Members");

                // Total peminjaman
                stats.TotalBorrowings = ExecuteCount("SELECT COUNT(*) FROM Borrowings");

                // Peminjaman aktif (status 'Dipinjam')
                stats.ActiveBorrowings = ExecuteCount("SELECT COUNT(*) FROM Borrowings WHERE Status = 'Dipinjam'");

                // Peminjaman terlambat (status 'Terlambat')
                stats.OverdueBorrowings = ExecuteCount("SELECT COUNT(*) FROM Borrowings WHERE Status = 'Terlambat'");
            }
            catch
            {
                // Biarkan nilai default (0) jika terjadi error; detail error akan ditangani di layer UI jika perlu
            }

            return stats;
        }

        private int ExecuteCount(string query, MySqlParameter[]? parameters = null)
        {
            object? result = db.ExecuteScalar(query, parameters);
            if (result == null || result == DBNull.Value)
            {
                return 0;
            }

            return Convert.ToInt32(result);
        }
    }
}
