using System.Data;
using MySql.Data.MySqlClient;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data
{
    public class BorrowingRepository
    {
        private readonly DatabaseHelper db;

        public BorrowingRepository()
        {
            db = new DatabaseHelper();
        }

        // CREATE - Tambah peminjaman baru
        public bool AddBorrowing(Borrowing borrowing)
        {
            try
            {
                string query = @"INSERT INTO Borrowings (BorrowingCode, MemberId, BookId, BorrowDate, DueDate, Status)
                                VALUES (@BorrowingCode, @MemberId, @BookId, @BorrowDate, @DueDate, @Status)";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@BorrowingCode", borrowing.BorrowingCode),
                    new MySqlParameter("@MemberId", borrowing.MemberId),
                    new MySqlParameter("@BookId", borrowing.BookId),
                    new MySqlParameter("@BorrowDate", borrowing.BorrowDate),
                    new MySqlParameter("@DueDate", borrowing.DueDate),
                    new MySqlParameter("@Status", borrowing.Status)
                };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // READ - Ambil semua peminjaman
        public List<Borrowing> GetAllBorrowings()
        {
            var borrowings = new List<Borrowing>();
            try
            {
                string query = @"SELECT b.*, m.FullName as MemberName, bk.Title as BookTitle, bk.BookCode
                               FROM Borrowings b
                               INNER JOIN Members m ON b.MemberId = m.MemberId
                               INNER JOIN Books bk ON b.BookId = bk.BookId
                               ORDER BY b.BorrowDate DESC";
                
                DataTable dt = db.ExecuteQuery(query);

                foreach (DataRow row in dt.Rows)
                {
                    borrowings.Add(MapToBorrowing(row));
                }
            }
            catch { }

            return borrowings;
        }

        // READ - Ambil peminjaman aktif (belum dikembalikan)
        public List<Borrowing> GetActiveBorrowings()
        {
            var borrowings = new List<Borrowing>();
            try
            {
                string query = @"SELECT b.*, m.FullName as MemberName, bk.Title as BookTitle, bk.BookCode
                               FROM Borrowings b
                               INNER JOIN Members m ON b.MemberId = m.MemberId
                               INNER JOIN Books bk ON b.BookId = bk.BookId
                               WHERE b.ReturnDate IS NULL
                               ORDER BY b.DueDate";
                
                DataTable dt = db.ExecuteQuery(query);

                foreach (DataRow row in dt.Rows)
                {
                    borrowings.Add(MapToBorrowing(row));
                }
            }
            catch { }

            return borrowings;
        }

        // READ - Ambil peminjaman by member
        public List<Borrowing> GetBorrowingsByMember(int memberId)
        {
            var borrowings = new List<Borrowing>();
            try
            {
                string query = @"SELECT b.*, m.FullName as MemberName, bk.Title as BookTitle, bk.BookCode
                               FROM Borrowings b
                               INNER JOIN Members m ON b.MemberId = m.MemberId
                               INNER JOIN Books bk ON b.BookId = bk.BookId
                               WHERE b.MemberId = @MemberId
                               ORDER BY b.BorrowDate DESC";

                MySqlParameter[] parameters = { new MySqlParameter("@MemberId", memberId) };
                DataTable dt = db.ExecuteQuery(query, parameters);

                foreach (DataRow row in dt.Rows)
                {
                    borrowings.Add(MapToBorrowing(row));
                }
            }
            catch { }

            return borrowings;
        }

        // READ - Search peminjaman
        public List<Borrowing> SearchBorrowings(string keyword)
        {
            var borrowings = new List<Borrowing>();
            try
            {
                string query = @"SELECT b.*, m.FullName as MemberName, bk.Title as BookTitle, bk.BookCode
                               FROM Borrowings b
                               INNER JOIN Members m ON b.MemberId = m.MemberId
                               INNER JOIN Books bk ON b.BookId = bk.BookId
                               WHERE b.BorrowingCode LIKE @Keyword 
                               OR m.FullName LIKE @Keyword
                               OR bk.Title LIKE @Keyword
                               ORDER BY b.BorrowDate DESC";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@Keyword", $"%{keyword}%")
                };

                DataTable dt = db.ExecuteQuery(query, parameters);
                foreach (DataRow row in dt.Rows)
                {
                    borrowings.Add(MapToBorrowing(row));
                }
            }
            catch { }

            return borrowings;
        }

        // UPDATE - Pengembalian buku
        public bool ReturnBook(int borrowingId, DateTime returnDate, decimal fine)
        {
            try
            {
                string query = @"UPDATE Borrowings SET 
                               ReturnDate = @ReturnDate,
                               Fine = @Fine,
                               Status = @Status
                               WHERE BorrowingId = @BorrowingId";

                // Tentukan status
                string status = fine > 0 ? "Terlambat" : "Dikembalikan";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@BorrowingId", borrowingId),
                    new MySqlParameter("@ReturnDate", returnDate),
                    new MySqlParameter("@Fine", fine),
                    new MySqlParameter("@Status", status)
                };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // Function untuk generate borrowing code
        public string GenerateBorrowingCode()
        {
            try
            {
                string query = "SELECT COUNT(*) FROM Borrowings";
                object? result = db.ExecuteScalar(query);
                int count = result != null ? Convert.ToInt32(result) : 0;
                
                return $"BRW{DateTime.Now:yyyyMMdd}{(count + 1):D4}";
            }
            catch
            {
                return $"BRW{DateTime.Now:yyyyMMddHHmmss}";
            }
        }

        // Helper method untuk mapping DataRow ke Borrowing object
        private Borrowing MapToBorrowing(DataRow row)
        {
            var borrowing = new Borrowing
            {
                BorrowingId = Convert.ToInt32(row["BorrowingId"]),
                BorrowingCode = row["BorrowingCode"].ToString() ?? "",
                MemberId = Convert.ToInt32(row["MemberId"]),
                BookId = Convert.ToInt32(row["BookId"]),
                BorrowDate = Convert.ToDateTime(row["BorrowDate"]),
                DueDate = Convert.ToDateTime(row["DueDate"]),
                ReturnDate = row["ReturnDate"] != DBNull.Value ? Convert.ToDateTime(row["ReturnDate"]) : null,
                Fine = row["Fine"] != DBNull.Value ? Convert.ToDecimal(row["Fine"]) : 0,
                Status = row["Status"].ToString() ?? "Dipinjam",
                MemberName = row["MemberName"].ToString(),
                BookTitle = row["BookTitle"].ToString(),
                BookCode = row["BookCode"].ToString()
            };

            return borrowing;
        }
    }
}
