using System.Data;
using MySql.Data.MySqlClient;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data
{
    public class MemberRepository
    {
        private readonly DatabaseHelper db;

        public MemberRepository()
        {
            db = new DatabaseHelper();
        }

        // CREATE - Tambah anggota baru
        public bool AddMember(Member member)
        {
            try
            {
                string query = @"INSERT INTO Members (MemberCode, FullName, Address, PhoneNumber, Email, JoinDate, IsActive)
                                VALUES (@MemberCode, @FullName, @Address, @PhoneNumber, @Email, @JoinDate, @IsActive)";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@MemberCode", member.MemberCode),
                    new MySqlParameter("@FullName", member.FullName),
                    new MySqlParameter("@Address", member.Address),
                    new MySqlParameter("@PhoneNumber", member.PhoneNumber),
                    new MySqlParameter("@Email", member.Email),
                    new MySqlParameter("@JoinDate", DateTime.Now),
                    new MySqlParameter("@IsActive", member.IsActive)
                };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // READ - Ambil semua anggota
        public List<Member> GetAllMembers()
        {
            var members = new List<Member>();
            try
            {
                string query = "SELECT * FROM Members ORDER BY FullName";
                DataTable dt = db.ExecuteQuery(query);

                foreach (DataRow row in dt.Rows)
                {
                    members.Add(MapToMember(row));
                }
            }
            catch { }

            return members;
        }

        // READ - Ambil anggota by ID
        public Member? GetMemberById(int memberId)
        {
            try
            {
                string query = "SELECT * FROM Members WHERE MemberId = @MemberId";
                MySqlParameter[] parameters = { new MySqlParameter("@MemberId", memberId) };
                
                DataTable dt = db.ExecuteQuery(query, parameters);
                if (dt.Rows.Count > 0)
                {
                    return MapToMember(dt.Rows[0]);
                }
            }
            catch { }

            return null;
        }

        // READ - Search anggota
        public List<Member> SearchMembers(string keyword)
        {
            var members = new List<Member>();
            try
            {
                string query = @"SELECT * FROM Members 
                               WHERE MemberCode LIKE @Keyword 
                               OR FullName LIKE @Keyword 
                               OR PhoneNumber LIKE @Keyword 
                               ORDER BY FullName";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@Keyword", $"%{keyword}%")
                };

                DataTable dt = db.ExecuteQuery(query, parameters);
                foreach (DataRow row in dt.Rows)
                {
                    members.Add(MapToMember(row));
                }
            }
            catch { }

            return members;
        }

        // READ - Ambil anggota aktif saja
        public List<Member> GetActiveMembers()
        {
            var members = new List<Member>();
            try
            {
                string query = "SELECT * FROM Members WHERE IsActive = 1 ORDER BY FullName";
                DataTable dt = db.ExecuteQuery(query);

                foreach (DataRow row in dt.Rows)
                {
                    members.Add(MapToMember(row));
                }
            }
            catch { }

            return members;
        }

        // UPDATE - Update anggota
        public bool UpdateMember(Member member)
        {
            try
            {
                string query = @"UPDATE Members SET 
                               MemberCode = @MemberCode,
                               FullName = @FullName,
                               Address = @Address,
                               PhoneNumber = @PhoneNumber,
                               Email = @Email,
                               IsActive = @IsActive
                               WHERE MemberId = @MemberId";

                MySqlParameter[] parameters = { new MySqlParameter("@MemberId", member.MemberId),
                    new MySqlParameter("@MemberCode", member.MemberCode),
                    new MySqlParameter("@FullName", member.FullName),
                    new MySqlParameter("@Address", member.Address),
                    new MySqlParameter("@PhoneNumber", member.PhoneNumber),
                    new MySqlParameter("@Email", member.Email),
                    new MySqlParameter("@IsActive", member.IsActive)
                };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // DELETE - Hapus anggota
        public bool DeleteMember(int memberId)
        {
            try
            {
                string query = "DELETE FROM Members WHERE MemberId = @MemberId";
                MySqlParameter[] parameters = { new MySqlParameter("@MemberId", memberId) };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // Helper method untuk mapping DataRow ke Member object
        private Member MapToMember(DataRow row)
        {
            return new Member
            {
                MemberId = Convert.ToInt32(row["MemberId"]),
                MemberCode = row["MemberCode"].ToString() ?? "",
                FullName = row["FullName"].ToString() ?? "",
                Address = row["Address"].ToString() ?? "",
                PhoneNumber = row["PhoneNumber"].ToString() ?? "",
                Email = row["Email"].ToString() ?? "",
                JoinDate = Convert.ToDateTime(row["JoinDate"]),
                IsActive = Convert.ToBoolean(row["IsActive"])
            };
        }
    }
}
