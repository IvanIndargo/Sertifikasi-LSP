using System.Data;
using MySql.Data.MySqlClient;
using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Data
{
    public class BookRepository
    {
        private readonly DatabaseHelper db;

        public BookRepository()
        {
            db = new DatabaseHelper();
        }

        // CREATE - Tambah buku baru
        public bool AddBook(Book book)
        {
            try
            {
                string query = @"INSERT INTO Books (BookCode, Title, Author, Publisher, PublishYear, Category, Stock, AvailableStock, CreatedDate)
                                VALUES (@BookCode, @Title, @Author, @Publisher, @PublishYear, @Category, @Stock, @AvailableStock, @CreatedDate)";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@BookCode", book.BookCode),
                    new MySqlParameter("@Title", book.Title),
                    new MySqlParameter("@Author", book.Author),
                    new MySqlParameter("@Publisher", book.Publisher),
                    new MySqlParameter("@PublishYear", book.PublishYear),
                    new MySqlParameter("@Category", book.Category),
                    new MySqlParameter("@Stock", book.Stock),
                    new MySqlParameter("@AvailableStock", book.AvailableStock),
                    new MySqlParameter("@CreatedDate", DateTime.Now)
                };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // READ - Ambil semua buku
        public List<Book> GetAllBooks()
        {
            var books = new List<Book>();
            try
            {
                string query = "SELECT * FROM Books ORDER BY Title";
                DataTable dt = db.ExecuteQuery(query);

                foreach (DataRow row in dt.Rows)
                {
                    books.Add(MapToBook(row));
                }
            }
            catch { }

            return books;
        }

        // READ - Ambil buku by ID
        public Book? GetBookById(int bookId)
        {
            try
            {
                string query = "SELECT * FROM Books WHERE BookId = @BookId";
                MySqlParameter[] parameters = { new MySqlParameter("@BookId", bookId) };
                
                DataTable dt = db.ExecuteQuery(query, parameters);
                if (dt.Rows.Count > 0)
                {
                    return MapToBook(dt.Rows[0]);
                }
            }
            catch { }

            return null;
        }

        // READ - Search buku
        public List<Book> SearchBooks(string keyword)
        {
            var books = new List<Book>();
            try
            {
                string query = @"SELECT * FROM Books 
                               WHERE BookCode LIKE @Keyword 
                               OR Title LIKE @Keyword 
                               OR Author LIKE @Keyword 
                               ORDER BY Title";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@Keyword", $"%{keyword}%")
                };

                DataTable dt = db.ExecuteQuery(query, parameters);
                foreach (DataRow row in dt.Rows)
                {
                    books.Add(MapToBook(row));
                }
            }
            catch { }

            return books;
        }

        // UPDATE - Update buku
        public bool UpdateBook(Book book)
        {
            try
            {
                string query = @"UPDATE Books SET 
                               BookCode = @BookCode,
                               Title = @Title,
                               Author = @Author,
                               Publisher = @Publisher,
                               PublishYear = @PublishYear,
                               Category = @Category,
                               Stock = @Stock,
                               AvailableStock = @AvailableStock
                               WHERE BookId = @BookId";

                MySqlParameter[] parameters = {
                    new MySqlParameter("@BookId", book.BookId),
                    new MySqlParameter("@BookCode", book.BookCode),
                    new MySqlParameter("@Title", book.Title),
                    new MySqlParameter("@Author", book.Author),
                    new MySqlParameter("@Publisher", book.Publisher),
                    new MySqlParameter("@PublishYear", book.PublishYear),
                    new MySqlParameter("@Category", book.Category),
                    new MySqlParameter("@Stock", book.Stock),
                    new MySqlParameter("@AvailableStock", book.AvailableStock)
                };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // DELETE - Hapus buku
        public bool DeleteBook(int bookId)
        {
            try
            {
                string query = "DELETE FROM Books WHERE BookId = @BookId";
                MySqlParameter[] parameters = { new MySqlParameter("@BookId", bookId) };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // UPDATE - Update stok buku
        public bool UpdateStock(int bookId, int availableStock)
        {
            try
            {
                string query = "UPDATE Books SET AvailableStock = @AvailableStock WHERE BookId = @BookId";
                MySqlParameter[] parameters = {
                    new MySqlParameter("@BookId", bookId),
                    new MySqlParameter("@AvailableStock", availableStock)
                };

                return db.ExecuteNonQuery(query, parameters) > 0;
            }
            catch
            {
                return false;
            }
        }

        // Helper method untuk mapping DataRow ke Book object
        private Book MapToBook(DataRow row)
        {
            return new Book
            {
                BookId = Convert.ToInt32(row["BookId"]),
                BookCode = row["BookCode"].ToString() ?? "",
                Title = row["Title"].ToString() ?? "",
                Author = row["Author"].ToString() ?? "",
                Publisher = row["Publisher"].ToString() ?? "",
                PublishYear = Convert.ToInt32(row["PublishYear"]),
                Category = row["Category"].ToString() ?? "",
                Stock = Convert.ToInt32(row["Stock"]),
                AvailableStock = Convert.ToInt32(row["AvailableStock"]),
                CreatedDate = Convert.ToDateTime(row["CreatedDate"])
            };
        }
    }
}
